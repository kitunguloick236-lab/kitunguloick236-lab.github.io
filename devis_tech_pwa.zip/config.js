/* Réglages de DEVIS TECH : modifie seulement les adresses entre guillemets */
window.DT_CONFIG = {
  AI_URL: "",
  LINKS: {
    youtube: "",
    tiktok: "",
    whatsapp: "https://wa.me/243990101747",
    facebook: ""
  }
};
